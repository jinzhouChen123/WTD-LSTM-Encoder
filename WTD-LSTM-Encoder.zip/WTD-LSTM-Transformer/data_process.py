# -*- coding:utf-8 -*-

import os
import random
from sklearn.preprocessing import MinMaxScaler
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm
import numpy as np
import pandas as pd
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
import numpy as np
import math
import pywt
#封装成函数
def sgn(num):
        if (num > 0):
            return 1.0
        elif (num == 0):
            return 0.0
        else:
            return -1.0


def wavelet_noising(new_df):
        data = new_df
        data = data.T.tolist()
        w = pywt.Wavelet('sym8')
        [ca5, cd5, cd4, cd3, cd2, cd1] = pywt.wavedec(data, w, level=5)  # 分解波
        length1 = len(cd1)
        length0 = len(data)
        Cd1 = np.array(cd1)
        abs_cd1 = np.abs(Cd1)
        median_cd1 = np.median(abs_cd1)
        sigma = (1.0 / 0.6745) * median_cd1
        lamda = sigma * math.sqrt(2.0 * math.log(float(length0), math.e))
        usecoeffs = []
        usecoeffs.append(ca5)
        a = 0.5

        for k in range(length1):
            if (abs(cd1[k]) >= lamda):
                cd1[k] = sgn(cd1[k]) * (abs(cd1[k]) - a * lamda)
            else:
                cd1[k] = 0.0

        length2 = len(cd2)
        for k in range(length2):
            if (abs(cd2[k]) >= lamda):
                cd2[k] = sgn(cd2[k]) * (abs(cd2[k]) - a * lamda)
            else:
                cd2[k] = 0.0

        length3 = len(cd3)
        for k in range(length3):
            if (abs(cd3[k]) >= lamda):
                cd3[k] = sgn(cd3[k]) * (abs(cd3[k]) - a * lamda)
            else:
                cd3[k] = 0.0

        length4 = len(cd4)
        for k in range(length4):
            if (abs(cd4[k]) >= lamda):
                cd4[k] = sgn(cd4[k]) * (abs(cd4[k]) - a * lamda)
            else:
                cd4[k] = 0.0

        length5 = len(cd5)
        for k in range(length5):
            if (abs(cd5[k]) >= lamda):
                cd5[k] = sgn(cd5[k]) * (abs(cd5[k]) - a * lamda)
            else:
                cd5[k] = 0.0

        usecoeffs.append(cd5)
        usecoeffs.append(cd4)
        usecoeffs.append(cd3)
        usecoeffs.append(cd2)
        usecoeffs.append(cd1)
        recoeffs = pywt.waverec(usecoeffs, w)
        return recoeffs


def denoise(x, data):
    data_denoising = wavelet_noising(data)


def setup_seed(seed):
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


def load_data(ali_mean_df=True):
    """
    :return:
    """
    path = os.path.dirname(os.path.realpath(__file__)) + '/data/streamwatertemperatures.csv'
    df = pd.read_csv(path, encoding='gbk')
    df.fillna(df.mean(), inplace=True)
    dm = df[df.columns[4]]
    dn = df[df.columns[10]]
    df = df[df.columns[5:9]]
    dm = dm.values.reshape(1274, 1)
    dn = dn.values.reshape(1274, 1)
    df = np.append(df, dn, axis=1)
    df = np.append(df, dm, axis=1)
    du = df
    du=pd.DataFrame(du)
    df = pd.DataFrame(df)
    print(df)
    for i in range(6):
        dt = df[df.columns[i]]
        dt = np.array(dt)
        dt = wavelet_noising(dt)
        dt = dt.reshape(-1, 1)
        du = np.append(du, dt, axis=1)
        du = np.delete(du, 0, axis=1)
    du = pd.DataFrame(du)
    print(du, type(du))
    df = du[du.columns[0:5]]
    dt = du[du.columns[5]]

    scaler = MinMaxScaler()
    scaler.fit(df)
    scaler.data_max_
    df = scaler.transform(df)
    dt = dt.values.reshape(1274, 1)
    df = np.append(df, dt, axis=1)
    df = pd.DataFrame(df)
    return df


class MyDataset(Dataset):
    def __init__(self, data):
        self.data = data

    def __getitem__(self, item):
        return self.data[item]

    def __len__(self):
        return len(self.data)



def nn_seq_mm(seq_len, B, num):
    #df.fillna(df.mean(), inplace=True)
    print('data processing...')
    dataset = load_data()
    # split
    train = dataset[:int(len(dataset) * 0.6)]
    val = dataset[int(len(dataset) * 0.6):int(len(dataset) * 0.8)]
    test = dataset[int(len(dataset) * 0.8):len(dataset)]
    m, n = np.max(train[train.columns[5]]), np.min(train[train.columns[5]])

    def process(data, batch_size, step_size, shuffle):
        load = data[data.columns[5]]
        data = data.values.tolist()
        load = (load - n) / (m - n)
        load = load.tolist()
        seq = []
        for i in tqdm(range(0, len(data) - seq_len - num, step_size)):
            train_seq = []
            train_label = []

            for j in range(i, i + seq_len):
                x = [load[j]]
                for c in range(0,4):
                    x.append(data[j][c])
                train_seq.append(x)

            for j in range(i + seq_len, i + seq_len + num):
                train_label.append(load[j])

            train_seq = torch.FloatTensor(train_seq)
            train_label = torch.FloatTensor(train_label).view(-1)
            seq.append((train_seq, train_label))

        # print(seq[-1])
        seq = MyDataset(seq)
        seq = DataLoader(dataset=seq, batch_size=batch_size, shuffle=shuffle, num_workers=0, drop_last=False)

        return seq

    Dtr = process(train, B, step_size=1, shuffle=True)
    Val = process(val, B, step_size=1, shuffle=True)
    Dte = process(test, B, step_size=num, shuffle=False)

    return Dtr, Val, Dte, m, n

def get_mape(x, y):
    """
    :param x: true value
    :param y: pred value
    :return: mape
    """
    return np.mean(np.abs((x - y) / x))
