# -*- coding:utf-8 -*-

from torch import nn
import torch

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class LSTM(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size, batch_size):
        super().__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.output_size = output_size
        self.num_directions = 1
        self.batch_size = batch_size
        self.lstm = nn.LSTM(self.input_size, self.hidden_size, self.num_layers, batch_first=True)
        self.linear = nn.Linear(self.hidden_size, self.output_size)

    def forward(self, input_seq):
        batch_size, seq_len = input_seq.shape[0], input_seq.shape[1]
        h_0 = torch.randn(self.num_directions * self.num_layers, batch_size, self.hidden_size).to(device)
        c_0 = torch.randn(self.num_directions * self.num_layers, batch_size, self.hidden_size).to(device)
        # print(input_seq.size())
        # input(batch_size, seq_len, input_size)
        # input_seq = input_seq.view(self.batch_size, seq_len, self.input_size)
        # output(batch_size, seq_len, num_directions * hidden_size)
        output, _ = self.lstm(input_seq, (h_0, c_0))
        # print('output.size=', output.size())
        # print(self.batch_size * seq_len, self.hidden_size)
        # output = output.contiguous().view(batch_size * seq_len, self.hidden_size)  # (5 * 30, 64)
        pred = self.linear(output)  # pred(batch_size, seq_len, output_size)
        # print('pred=', pred.shape)
        # pred = pred.view(batch_size, seq_len, -1)
        pred = pred[:, -1, :]

        return pred
class LSTMModel(nn.Module):
    def __init__(self,input_size,hidden_size,num_layers):
        super(LSTMModel,self).__init__()
        self.lstm=nn.LSTM(input_size,hidden_size,num_layers,batch_first=True)

    def forward(self,x):
        output,_=self.lstm(x)
        return output
class TransformerModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers):
        super(TransformerModel,self).__init__()
        self.transformer=nn.TransformerEncoderLayer(input_size,nhead=1,dim_feedforward=hidden_size,batch_first=True)
        #self.num_layers=num_layers
        #self.transformer_encoder=nn.TransformerEncoderLayer(self.transformer,self.num_layers)
    def forward(self,x):
        output=self.transformer(x)
        return output
class LSTMTransformerModel(nn.Module):
    def __init__(self,lstm_hidden_size,lstm_num_layers,transformer_hidden_size,input_size,transformer_num_layers,output_size):
        super(LSTMTransformerModel,self).__init__()
        self.lstm=LSTMModel(input_size,lstm_hidden_size,lstm_num_layers)
        self.transformer=TransformerModel(lstm_hidden_size,transformer_hidden_size,transformer_num_layers)
        self.fc=nn.Linear(transformer_hidden_size,output_size,)
    def forward(self,x):
        lstm_output=self.lstm(x)
        transformer_output=self.transformer(lstm_output)
        pred=self.fc(transformer_output[:, -1, :])
        return pred

class BiLSTM(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size, batch_size):
        super().__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.output_size = output_size
        self.num_directions = 2
        self.batch_size = batch_size
        self.lstm = nn.LSTM(self.input_size, self.hidden_size, self.num_layers, batch_first=True, bidirectional=True)
        self.linear = nn.Linear(self.hidden_size, self.output_size)

    def forward(self, input_seq):
        batch_size, seq_len = input_seq.shape[0], input_seq.shape[1]
        h_0 = torch.randn(self.num_directions * self.num_layers, batch_size, self.hidden_size).to(device)
        c_0 = torch.randn(self.num_directions * self.num_layers, batch_size, self.hidden_size).to(device)
        # print(input_seq.size())
        # input(batch_size, seq_len, input_size)
        # output(batch_size, seq_len, num_directions * hidden_size)
        output, _ = self.lstm(input_seq, (h_0, c_0))
        output = output.contiguous().view(batch_size, seq_len, self.num_directions, self.hidden_size)
        output = torch.mean(output, dim=2)
        # output = output.contiguous().view(self.batch_size * seq_len, self.hidden_size)  # (5 * 30, 64)
        pred = self.linear(output)  # pred()
        #print('pred=', pred.shape)
        #pred = pred.view(self.batch_size, seq_len, -1)
        pred = pred[:, -1, :]

        return pred
